CREATE DATABASE story_ai;
use story_ai;
CREATE TABLE story_list(
    sno int auto_increment,
    story_title varchar(255),
    language varchar(255),
    country varchar(255),
    author varchar(255),
    inserted_time TIMESTAMP,
    story_data blob
);

INSERT INTO story_list(story_title,language,country,author,story_data)
 VALUES (%s,%s,%s,%s,%s);

 INSERT INTO story_list(story_title,language,country,author,story_data)
 VALUES ('gam ganesha','telugu','india','shiva',LOAD_FILE(/MAIN.PY));