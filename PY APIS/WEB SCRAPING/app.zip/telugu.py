def speak(text):
    from gtts import gTTS
    import pygame
    import os
    import random
    import string

    try:
        # Generate a unique filename to avoid conflicts
        filename = 'main.mp3'

        # Convert text to speech
        tts = gTTS(text=text, lang='te')
        tts.save(filename)

        # Initialize pygame mixer
        pygame.mixer.init()

        # Load the mp3 file
        pygame.mixer.music.load(filename)

        # Play the mp3 file
        pygame.mixer.music.play()


    except Exception as e:
        print(f"An error occurred: {e}")


