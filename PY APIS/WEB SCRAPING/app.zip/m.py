def con():
    import pymysql
    host = "192.168.0.114"
    user = "admin"
    password = "11971197"
    database_name = 'story_ai'
    try:
        # Connect to the MySQL server
        con = pymysql.connect(host=host, user=user, password=password, database=database_name)
        # Create a cursor object to execute SQL queries
        cur = con.cursor()
        try:
            sql = "SELECT story_data FROM story_list WHERE story_title = %s"
            cur.execute(sql,'hooo')
            result = cur.fetchone()
            print(result[0])
            story=result[0]
            import pyttsx3 as pt
            # Text-to-speech engine
            engine = pt.init()
            engine.say(story)
            engine.runAndWait()
        except:
            pass
    except:
        pass

# con()

def read(stry):
    import pyttsx3 as pt
    # Text-to-speech engine
    engine = pt.init()
    engine.say(stry)
    engine.runAndWait()

read('hello anna')