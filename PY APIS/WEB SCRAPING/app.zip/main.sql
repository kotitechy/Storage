CREATE DATABASE story_ai;
use story_ai;
CREATE TABLE story_list(
    sno int auto_increment primary key,
    story_title varchar(255),
    language varchar(255),
    country varchar(255),
    author varchar(255),
    inserted_time TIMESTAMP,
    story_data text
);

f'INSERT INTO story_list(story_title,language,country,author,story_data)
VALUES (%s,%s,%s,%s,%s);',(story_title,language,country,author,LOAD_FILE({file_path}))

 INSERT INTO story_list(story_title,language,country,author,story_data)
 VALUES ('hooo','telugu','bharath','vamshi',LOAD_FILE('story.txt'));
 INSERT INTO story_list (story_title, language, country, author, story_data)
VALUES ('amma', 'telugu', 'bharath', 'vamshi', 'In the poem, Amma the poet talks about a grandmother whose days are counted. Even then she engages in more household activities in a house that is old like her. She seems to live alone as there are no other voices other than the echoes of her slow footsteps.');
drop table story_list;

select * from story_list;

SELECT story_data 
FROM story_list 
WHERE story_title = 'hooo';

