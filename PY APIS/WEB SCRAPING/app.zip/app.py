import pymysql 
import pyttsx3 as pt
import streamlit as st
from telugu import speak
# Database connection function
def con():
    host = "192.168.0.114"
    user = "admin"
    password = "11971197"
    database_name = 'story_ai'
    try:
        # Connect to the MySQL server
        connection = pymysql.connect(host=host, user=user, password=password, database=database_name)
        # Create a cursor object to execute SQL queries
        cursor = connection.cursor()
        return [connection, cursor]
    except Exception as e:
        return e

c = con()
if isinstance(c, list):
    con = c[0]
    cur = c[1]
else:
    st.error("Could not connect to the database.")

# Function to retrieve and read the story
def retrieve_file(file_id):
    try:
        try:
            sql = "SELECT story_data FROM story_list WHERE story_title = %s"
            cur.execute(sql,file_id)
            result = cur.fetchone()
            print(result[0])
            return result[0]
        except Exception as e:
            st.error(e)
    except Exception as e:
        st.error(e)

def read(stry):
    import pyttsx3 as pt
    # Text-to-speech engine
    print('stry: ',stry)
    engine = pt.init()
    engine.say(stry)
    engine.runAndWait()

# Streamlit UI
telugu=st.sidebar.selectbox('telugu stories',[x for x in range(50)])
hindi=st.sidebar.selectbox('hindi stories',[x for x in range(50)])
english=st.sidebar.selectbox('english stories',[x for x in range(50)])
tamil=st.sidebar.selectbox('tamil stories',[x for x in range(50)])
kannadam=st.sidebar.selectbox('kannadam stories',[x for x in range(50)])
sanskrit=st.sidebar.selectbox('sanskrit stories',[x for x in range(50)])


st.title('Story Telling AI')
ip=st.text_input('Search for a story')
if(st.button('Get story')):
    if(ip==''):
       st.write('response')
       st.error('Serch a for an valid story')
    st.write('input: \n',ip)
    story=retrieve_file(ip)
    st.write('Response')
    st.write('Story: ')
    st.write(story)
    read(story)