import pymysql
import pyttsx3 as pt
import streamlit as st
from telugu import speak
# Database connection function
def con():
    host = "192.168.0.114"
    user = "admin"
    password = "11971197"
    database_name = 'story_ai'
    try:
        # Connect to the MySQL server
        connection = pymysql.connect(host=host, user=user, password=password, database=database_name)
        # Create a cursor object to execute SQL queries
        cursor = connection.cursor()
        return [connection, cursor]
    except Exception as e:
        return e

# Establish connection
c = con()
if isinstance(c, list):
    con = c[0]
    cur = c[1]
else:
    st.error("Could not connect to the database.")

# Function to write a story to the database
def write_story(story_title, language, country, author, story_data):
    try:
        cur.execute("INSERT INTO story_list (story_title, language, country, author, story_data) VALUES (%s,%s,%s,%s,%s);",
                    (story_title, language, country, author, story_data))
        con.commit()
        st.success('Story written successfully!')
    except Exception as e:
        st.error(f"Error: {e}")

# Function to retrieve and read the story
def retrieve_file(file_id,lang):
    try:
        sql = "SELECT story_data FROM story_list WHERE story_title = %s and language = %s "
        cur.execute(sql, (file_id,lang) )
        result = cur.fetchone()
        if result:
            return result[0]
        else:
            return "Story not found"
    except Exception as e:
        st.error(e)

def read_story(story):
    # Text-to-speech engine
    engine = pt.init()
    engine.say(story)
    engine.runAndWait()

# Navigation Menu using Sidebar
st.sidebar.title("Story Application")
page = st.sidebar.selectbox("Choose a page", [ "Retrieve a Story","Write a Story"])

# Page 1: Write a Story
if page == "Write a Story":
    st.title("Write a New Story")

    with st.form(key='story_form'):
        story_title = st.text_input('Story Title', key='story_title')
        story_language = st.text_input('Story Language', key='story_language')
        story_country = st.text_input('Story Country', key='story_country')
        story_author = st.text_input('Story Author', key='story_author')
        story = st.text_area('Story', key='story')

        submit_button = st.form_submit_button('Submit')

        if submit_button:
            if not all([story_title, story_language, story_country, story_author, story]):
                st.error('Please fill all the fields.')
            else:
                write_story(story_title, story_language, story_country, story_author, story)

# Page 2: Retrieve a Story
elif page == "Retrieve a Story":
    st.title('Retrieve and Listen to a Story')
    
    language = st.selectbox('Choose language:', ['Telugu', 'Hindi', 'English', 'Tamil', 'Kannada', 'Sanskrit'])
    ip = st.text_input('Search for a story by title')

    if st.button('Get Story'):
        if ip == '':
            st.error('Please enter a valid story title')
        else:
            story = retrieve_file(ip,language)
            
            if story != "Story not found":
                st.write(f'Story: {story}')
                st.write('story not found')

            if(language=='Telugu'):
                speak(story)
            if(language=="English"):
                read_story(story)