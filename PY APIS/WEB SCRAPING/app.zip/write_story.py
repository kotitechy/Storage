import streamlit as st
def con():
    import pymysql
    host = "192.168.0.114"
    user = "admin"
    password = "11971197"
    database_name = 'story_ai'
    try:
        # Connect to the MySQL server
        connection = pymysql.connect(host=host, user=user, password=password, database=database_name)
        # Create a cursor object to execute SQL queries
        cursor = connection.cursor()
        return [connection, cursor]
    except Exception as e:
        return e
def read(stry):
    import pyttsx3 as pt
    # Text-to-speech engine
    print('stry: ',stry)
    engine = pt.init()
    engine.say(stry)
    engine.runAndWait() 

c = con()
if isinstance(c, list):
    con = c[0]
    cur = c[1]
else:
    st.error("Could not connect to the database.")
def write_story(story_title,language,country,author,story_data):
    try:
        cur.execute("INSERT INTO story_list (story_title, language, country, author, story_data) VALUES (%s,%s,%s,%s,%s);",(story_title,language,country,author,story_data))
        con.commit()
        st.success('story written')
    except Exception as e:
        st.information(e)
show_form = st.sidebar.button('Write a story')
def clear_form():
    st.session_state["story_title"] = ""
    st.session_state["story_language"] = ""
    st.session_state["story_country"] = ""
    st.session_state["story_author"] = ""
    st.session_state["story"] =''
import streamlit as st

# Set the title of the app
st.title("Story Submission Form")

# Create a form
with st.form(key='story_form'):
    story_title = st.text_input('Story Title')
    story_language = st.text_input('Story Language')
    story_country = st.text_input('Story Country')
    story_author = st.text_input('Story Author')
    story = st.text_area('Story')

    # Submit button inside the form
    submit_button = st.form_submit_button('Submit')

    if submit_button:
        # Check if any field is empty
        if story_title == '' or story_language == '' or story_country == '' or story_author == '' or story == '':
            st.error('Please fill all the columns.')
        else:
            # Call the function to write the story when all fields are filled
            write_story(story_title, story_language, story_country, story_author, story)
            st.success('Story written successfully!')
            clear_form()