import pymysql

# Database connection details
db_config = {
    'host': 'localhost',
    'user': 'your_username',  # Replace with your MySQL username
    'password': 'your_password',  # Replace with your MySQL password
    'database': 'chatbot_db'
}

def insert_question(question_text, category):
    try:
        # Connect to the MySQL database
        conn = pymysql.connect(**db_config)
        cursor = conn.cursor()

        # Insert a new question into the Questions table
        query = "INSERT INTO Questions (question_text, category) VALUES (%s, %s)"
        cursor.execute(query, (question_text, category))

        # Commit the transaction
        conn.commit()

        print("Question inserted successfully.")

    except pymysql.MySQLError as e:
        print(f"Error: {e}")
    finally:
        conn.close()

def insert_answer(category, response):
    try:
        # Connect to the MySQL database
        conn = pymysql.connect(**db_config)
        cursor = conn.cursor()

        # Insert a new answer into the Answers table
        query = "INSERT INTO Answers (category, response) VALUES (%s, %s)"
        cursor.execute(query, (category, response))

        # Commit the transaction
        conn.commit()

        print("Answer inserted successfully.")

    except pymysql.MySQLError as e:
        print(f"Error: {e}")
    finally:
        conn.close()

# Example of inserting a new question and answer
if __name__ == "__main__":
    # Insert a new question
    question_text = input("Enter the question: ")
    category = input("Enter the category for this question: ")
    insert_question(question_text, category)

    # Insert a new answer
    response = input("Enter the response for this category: ")
    insert_answer(category, response)
