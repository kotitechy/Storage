-- Create the database
CREATE DATABASE IF NOT EXISTS chatbot;

-- Use the created database
USE chatbot;

-- Create the Questions table
CREATE TABLE IF NOT EXISTS Questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question_text varchar(255) UNIQUE,
    category TEXT
);


-- Create the Answers table
CREATE TABLE IF NOT EXISTS Answers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category TEXT,
    response TEXT
);

select * from answers;
select * from questions;