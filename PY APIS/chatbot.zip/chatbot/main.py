from flask import Flask, request, render_template, redirect, url_for
import pymysql

# Initialize the Flask app
app = Flask(__name__)

# Database configuration
db_config = {
    'host': 'localhost',
    'user': 'root',  # Replace with your MySQL username
    'password': 'root',  # Replace with your MySQL password
    'database': 'chatbot'
}

# Route for inserting question and category
@app.route('/insert', methods=['GET', 'POST'])
def insert():
    if request.method == 'POST':
        question_text = request.form['question']
        category = request.form['category']
        response = request.form['response']
        
        # Insert the question into the database
        conn = pymysql.connect(**db_config)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO Questions (question_text, category) VALUES (%s, %s)", (question_text, category))
        cursor.execute("INSERT INTO Answers (category, response) VALUES (%s, %s)", (category, response))
        conn.commit()
        conn.close()

        return redirect(url_for('insert_success'))
    
    return render_template('insert.html')

# Route for querying a question
@app.route('/query', methods=['GET', 'POST'])
def query():
    if request.method == 'POST':
        question = request.form['question']
        
        # Fetch category and response from the database
        conn = pymysql.connect(**db_config)
        cursor = conn.cursor()
        cursor.execute("SELECT category FROM Questions WHERE question_text = %s", (question,))
        result = cursor.fetchone()
        
        if result:
            category = result[0]
            cursor.execute("SELECT response FROM Answers WHERE category = %s", (category,))
            answer = cursor.fetchone()
            conn.close()
            
            if answer:
                return render_template('query.html', question=question, answer=answer[0])
            else:
                return render_template('query.html', question=question, answer="No response found.")
        else:
            return render_template('query.html', question=question, answer="Question not found.")
    
    return render_template('query.html')

# Route for success after insertion
@app.route('/insert_success')
def insert_success():
    return "Question and response inserted successfully!"

# Run the app
if __name__ == '__main__':
    app.run(debug=True)
