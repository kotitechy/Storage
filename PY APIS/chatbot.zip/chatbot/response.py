import pymysql

# Database connection details
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'root', 
    'database': 'chatbot'
}

def get_response(question):
    try:
        # Connect to the MySQL database
        conn = pymysql.connect(**db_config)
        cursor = conn.cursor()

        # Find the category for the user's question
        query = "SELECT category FROM Questions WHERE question_text = %s"
        cursor.execute(query, (question,))
        result = cursor.fetchone()

        if result:
            category = result[0]
            # Find a matching response for the category
            query = "SELECT response FROM Answers WHERE category = %s"
            cursor.execute(query, (category,))
            response = cursor.fetchone()

            if response:
                return response[0]
            else:
                return "I don't know how to answer that."
        else:
            return "Sorry, I don't understand the question."

    except pymysql.MySQLError as e:
        print(f"Error: {e}")
        return "Sorry, there was a database error."
    
    finally:
        # Close the connection
        conn.close()

# Example of asking a question
if __name__ == "__main__":
    user_question = input("Ask a question: ")
    response = get_response(user_question)
    print(f"Chatbot: {response}")
