import sqlite3 as sl


class database:
    host = ''
    passwd = ''
    db = ''
    usr = ''

    def con(self):
        try:
            db = sl.connect('msg.db')
            print('connected to db')
            try:
                conn = db.cursor()
                print('cursor created')
            except Exception as e:
                print(e)

        except Exception as e:
            print(e)


db1 = database()
db1.con()
