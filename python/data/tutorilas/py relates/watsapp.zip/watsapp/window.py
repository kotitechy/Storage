import tkinter as tk
from PIL import ImageTk, Image


class window:
    def get_det(self):
        email = self.e_i.get()
        passc = self.ps_i.get()
        print(email, passc)

    def sign_in(self):
        pass

    def g_s(self):
        self.l_l.destroy()
        self.g_s_b.destroy()
        self.pg1()

    def pg1(self):
        self.logo = tk.Label(self.root, text='Log in')
        self.logo.place(x=500, y=100)

        # input
        # 1. email
        # 2. pass-code
        self.e_l = tk.Label(self.root, text='Enter Your Email-Id')
        self.ps_l = tk.Label(self.root, text='Enter Your Pass-code')
        self.e_l.place(x=500, y=200)
        self.ps_l.place(x=500, y=300)

        # input
        self.e_i = tk.Entry(self.root)
        self.ps_i = tk.Entry(self.root)
        self.e_i.place(x=500, y=250)
        self.ps_i.place(x=500, y=350)

        # submit
        self.submit = tk.Button(self.root, text='LogIn', command=self.get_det)
        self.submit.place(x=500, y=400)

        # signin
        self.crt_ac = tk.Label(self.root, text='Create an Account')
        self.crt_ac.place(x=500, y=500)
        self.sin_b = tk.Button(self.root, text='Signin')
        self.sin_b.place(x=550,y=550)

    def win(self):
        self.root = tk.Tk()

        S_W = self.root.winfo_screenwidth()  # 1360
        S_H = self.root.winfo_screenheight()  # 768

        self.root.geometry(f'{S_W}x{S_H}')
        self.root.configure(bg='lavender')

        # image -- logo
        self.i_path = 'logo.png'
        self.image = Image.open(self.i_path)
        self.l_img = ImageTk.PhotoImage(self.image)
        self.l_l = tk.Label(self.root, image=self.l_img)
        self.l_l.place(x=100, y=100)

        # get started button
        self.g_s_b = tk.Button(self.root, text='GET STARTED', command=self.g_s)
        self.g_s_b.place(x=500, y=300)

        self.root.mainloop()


w = window()
w.win()
