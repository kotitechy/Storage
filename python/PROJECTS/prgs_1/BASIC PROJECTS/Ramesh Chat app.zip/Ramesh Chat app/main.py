import tkinter as tk
from datetime import datetime

import mysql.connector

class sin:
    def clk(self):
        n = self.chat.get().lower()
        print("Ramesh: ", n)

        try:
            db = mysql.connector.connect(host='localhost', user='root', passwd='root', database='private_chat')
            cur = db.cursor()
            print('Successfully connected to db')
        except:
            print("Can't connect to server at the moment")

        try:
            current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            print(current_time)
            q = f'INSERT INTO chat_tab (sno, msg, cht_time) VALUES (12, "{n}", "{current_time}")'
            cur.execute(q)
            # Commit the changes
            db.commit()
            self.stat_l.config(text="Msg Sent")
            print('Successfully Inserted data')
        except Exception as e:
            print(e)
    def ref(self):
        try:
            db = mysql.connector.connect(host='localhost', user='root', passwd='root', database='private_chat')
            cur = db.cursor()
            print('Successfully connected to db')
        except:
            print("Can't connect to server at the moment")
        
        try:
            q = "USE private_chat"
            cur.execute(q)
            q = "select msg from chat_tab where sno = 12"
            cur.execute(q)
            r = cur.fetchall()
            print(r)

            # Clear existing messages
            self.chat_listbox.delete(0, tk.END)

            # Insert fetched messages
            for row in r:
                self.chat_listbox.insert(tk.END, row[0])
        except Exception as e:
            print(e)

    def signin(self):
        sin = tk.Tk()
        sin.title('Signin')
        sin.geometry('800x500')

        self.chat = tk.Entry(sin)
        self.chat.place(x=100, y=100)

        usr_l = tk.Label(sin, text='Enter Chat')
        chat_w_l = tk.Label(sin, text="RAMESH'S PRIVATE CHAT APP")
        self.stat_l = tk.Label(sin, text=" ")
        usr_l.place(x=10, y=100)
        chat_w_l.place(x=10, y=10)
        self.stat_l.place(x=10, y=55)

        con = tk.Button(sin, text='send msg', command=self.clk)
        con.place(x=10, y=30)        
        
        ref = tk.Button(sin, text='Refresh', command=self.ref)
        ref.place(x=80, y=30)

        # Listbox to display messages
        self.chat_listbox = tk.Listbox(sin)
        self.chat_listbox.place(x=300, y=50, width=250, height=400)

        sin.mainloop()


s = sin()
s.signin()