import mysql.connector
from datetime import datetime

def con():
    cur = None
    db = None
    try:
        db = mysql.connector.connect(host='localhost', user='root', passwd='root')
        cur = db.cursor()
        print('Successfully connected to db')
    except Exception as e:
        print(f'Failed to connect to db: {e}')
    
    return cur, db

def db_c():
    cur, db = con()
    if cur and db:
        try:
            cur.execute(f'CREATE DATABASE private_chat ')
            db.commit()
            print('Successfully created db')
        except Exception as e:
            print(f'Failed to create db: {e}')

def usr_t():
    cur, db = con()
    if cur and db:
        try:
            cur.execute(f'USE private_chat')
            cur.execute('CREATE TABLE users (sno int not null, name varchar(50) not null)  ')
            db.commit()
        except:
            print('Failed to create table users')
        try:
            cur.execute(f'CREATE TABLE chat_tab (sno int not null, msg varchar(255) not null, cht_time DATETIME )')
            db.commit()
        except:
            print('failed to create chat_tab table')
        try:
            current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            print(current_time)
            q = f'INSERT INTO chat_tab (sno, msg, cht_time) VALUES (12, "Default user", "{current_time}")'
            cur.execute(q)
            # Commit the changes
            db.commit()
            print('Successfully Inserted data')
        except Exception as e:
            print(e)

# Example usage:
# Uncomment and use the following lines to test the functions
db_c()
usr_t()